# stringToLower.py

def stringToLower(inStr):
    return inStr.lower()